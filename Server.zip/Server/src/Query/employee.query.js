// import employee table column from model
const Employee_Data = require("../Models/employee.model");

// getting database connection from db
const dbconnection = require("../Config/DataBase");

// getting all employee query 
Employee_Data.getAllemployee = function (result) {
  let getQuery = "SELECT * FROM employees";
  dbconnection.query(getQuery, (err, res) => {
    if (err) {
      console.log("Error while fetching emloyee data", err);
      result(null, err);
    } else {
      console.log("Employee Fetch successfully");
      result(null, res);
    }
  });
};

// get employee from id query
Employee_Data.getEmployeeById = function (id, result) {
  let getByidquery = "SELECT * FROM employees WHERE id=?";
  dbconnection.query(getByidquery, id, (err, res) => {
    if (err) {
      console.log("Error while Fetching employee data with id", err);
      result(null, err);
    } else {
      console.log("Data Fetch Successfully with id");
      result(null, res);
    }
  });
};

// create new employee data
Employee_Data.createEmployee = function (employeeData, result) {
  let createQuery = "INSERT INTO employees SET ?";
  dbconnection.query(createQuery, employeeData, (err, res) => {
    if (err) {
      console.log("Employee Created Successfully", res);
      result(null, err);
    } else {
      console.log("Employee Created Successfully with Data");
      result(null, res);
    }
  });
};

// update employee

Employee_Data.updateEmployee = function (id, employeeData, result) {
  let updateQuery =
    "UPDATE employees SET first_name=?,lasrt_name=?,email=?,phone=?,organization=?,designation=?,salary=? WHERE id = ?";
  dbconnection.query(
    updateQuery,
    [
      employeeData.first_name,
      employeeData.lasrt_name,
      employeeData.email,
      employeeData.phone,
      employeeData.organization,
      employeeData.designation,
      employeeData.salary,
      id,
    ],
    (err, res) => {
      if (err) {
        console.log("Error while Updating Employee Data");
        result(null, err);
      } else {
        console.log("Employee Data Updated Successfully");
        result(null, res);
      }
    }
  );
};

// delete employee data

Employee_Data.deletEmployeeData = function (id, result) {
  let deleteQuery = "DELETE FROM employees  WHERE id = ? ";
  dbconnection.query(deleteQuery, [id], (err, res) => {
    if (err) {
      console.log("Error while Deleting Emloyee Data");
      result(null, err);
    } else {
      console.log("Employee Data Successfully Deleted from Database");
      result(null, res);
    }
  });
};

module.exports = Employee_Data;

// updating Employee data with query  step3 
