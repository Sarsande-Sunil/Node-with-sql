const mysql = require("mysql");

// create database config
const databaseConfig = {
  host: "localhost",
  user: "root",
  password: "",
  database: "node_sql_curd",
};

// create mysql connection here
const dbconnection = mysql.createConnection(databaseConfig);

// connecting with database using mysql
dbconnection.connect(function (error) {
  if (error) throw error;
  console.log("Database Connected Successfully!!!");
});

module.exports = dbconnection;

// step1 connecting with database 
