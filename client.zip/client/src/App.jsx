import './App.css';
import Curd from './Componets/Curd';
import Post from './Componets/Post';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Single from './Componets/Single';
import { Update } from './Componets/Update';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Curd />} />
          <Route path="/post" element={<Post />} />
          <Route path="/update/:id" element={<Update/>} />
          <Route path='/singleview/:id' element={<Single/> } />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
