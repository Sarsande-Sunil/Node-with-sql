import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import "./single.css";
const Single = () => {
    const { id } = useParams();
    const [sedata, setSeData] = useState([]);
    console.log(id);
    const url = `http://localhost:4000/api/v1/employee/${id}`;
    const FetchData = async() => {
        try {
            const res = await fetch(url);
            const data = await (res.json());
            setSeData(data);
        }
        catch (err) {
            console.log(err)
        }
    }
    useEffect(() => {
       FetchData()
   },[])
    console.log(sedata)
    return (
      <div className="view-container">
        <h1>View Single Employee Details</h1>
        <h3>{"firstname-- "+sedata[0]?.first_name}</h3>
            <h3>{"lastname-- " + sedata[0]?.lasrt_name}</h3>
            <h3>{"email-- "+sedata[0]?.email}</h3>
            <h3>{"organization-- " + sedata[0]?.organization}</h3>
            <h3>{"designation-- "+sedata[0]?.designation}</h3>
            <h3>{"phone-- " + sedata[0]?.phone}</h3>
             <h3>{ "salary-- "+sedata[0]?.salary}</h3>
      </div>
    );
}

export default Single




