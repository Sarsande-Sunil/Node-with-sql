import React, { useEffect } from "react";
import { useState } from "react";
import "./Curd.css";
import { useNavigate } from "react-router-dom"
import axios from "axios"
const Curd = () => {
  const [edata, setEdata] = useState([]);
  const navigate = useNavigate();
  const fatchData = async () => {
    const result = await fetch("http://localhost:4000/api/v1/employee/all");
    const data = await result.json();
    setEdata([...data]);
  };
  useEffect(() => {
    fatchData();
  }, []);

  const DeleteData = (id) => {
    console.log(id)
    axios.delete(`http://localhost:4000/api/v1/employee/delete/${id}`).then(() => {
      fatchData()
    }).catch((err) => {
      console.log(err)
    });
  };
  
  const AddData = () => {
    navigate("/post")
  }

  const UpdateData = (id) => {
    navigate(`/update/${id}`)
  }

  const ViewData = (id) => {
    navigate(`/singleview/${id}`);
  };

  console.log(edata);
  return (
    <div className="Table_data">
      <h1>Employee Managment System</h1>
      <table>
        <thead>
          <tr id="heading">
            <th>FirstName</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Organization</th>
            <th>Designation</th>
            <th>Salary</th>
            <th>Delete</th>
            <th>Add</th>
            <th>Update</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          {edata.map((item, i) => (
            <tr key={i}>
              <td>{item.first_name}</td>
              <td>{item.lasrt_name}</td>
              <td>{item.email}</td>
              <td>{item.phone}</td>
              <td>{item.organization}</td>
              <td>{item.designation}</td>
              <td>{item.salary}</td>
              <td>
                <button onClick={() => DeleteData(item.id)}>Delete</button>
              </td>
              <td>
                <button onClick={() => AddData()}>Add</button>
              </td>
              <td>
                <button onClick={() => UpdateData(item.id)}>Update</button>
              </td>
              <td>
                <button onClick={() => ViewData(item.id)}>view</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Curd;
