import React from 'react'
import { useState } from "react";
import axios from "axios";
import "./update.css";
import { useNavigate } from "react-router-dom";
import { useParams } from 'react-router-dom';
export const Update = () => {
  const { id } = useParams();
  console.log('id',id)
  const url = `http://localhost:4000/api/v1/employee/update/${id}`;

  const navigate = useNavigate();
  const [data, setData] = useState({
    first_name: "",
    lasrt_name: "",
    email: "",
    phone: "",
    organization: "",
    designation: "",
    salary: "",
    status: "",
    created_at: "",
    updated_at: "",
  });

  const handle = (e) => {
    const newData = { ...data };
    newData[e.target.id] = e.target.value;
    setData(newData);
    console.log(data);
  };

  const submit = (e) => {
    e.preventDefault();
    axios
      .put(url, {
        first_name: data.first_name,
        lasrt_name: data.lasrt_name,
        email: data.email,
        phone: data.phone,
        organization: data.organization,
        designation: data.designation,
        salary: parseInt(data.salary),
        status: data.status,
        created_at: data.created_at,
        updated_at: data.updated_at,
      })
      .then((res) => {
        console.log(res.data);
      });
    alert("Employee Updated Successfully");
    navigate("/");
  };
  return (
    <div className="Form-Container">
      <h1>Update Employee Details</h1>
      <form action="" onSubmit={(e) => submit(e)} className="form-container">
        <input
          type="text"
          placeholder="First Name"
          id="first_name"
          value={data.first_name}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="Last Name"
          id="lasrt_name"
          value={data.lasrt_name}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="email"
          id="email"
          value={data.email}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="phone"
          id="phone"
          value={data.phone}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="organization"
          id="organization"
          value={data.organization}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="designation"
          id="designation"
          value={data.designation}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="salary"
          id="salary"
          value={data.salary}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="status"
          id="status"
          value={data.status}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="created_at"
          id="created_at"
          value={data.created_at}
          onChange={(e) => handle(e)}
        />
        <input
          type="text"
          placeholder="updated_at"
          id="updated_at"
          value={data.updated_at}
          onChange={(e) => handle(e)}
        />
        <input type="submit" />
      </form>
    </div>
  );
}
