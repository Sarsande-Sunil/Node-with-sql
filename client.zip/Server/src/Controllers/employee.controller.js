// getting Employee Data with prebuild query format

const Employee_Data = require("../Query/employee.query");

// get all employee
exports.getAllEmployeeList = (req, res) => {
  Employee_Data.getAllemployee((err, employees) => {
    try {
      res.status(200).send(employees);
    } catch (err) {
      res.status(400).send(err);
    }
  });
};

// get employee by Id

exports.getEmployeeByid = (req, res) => {
  Employee_Data.getEmployeeById(req.params.id, (err, employees) => {
    try {
      res.status(200).send(employees);
    } catch (err) {
      res.status(400).send(err);
    }
  });
};

// create new employeeif

exports.createNewEmployee = (req, res) => {
  const employeeData = new Employee_Data(req.body);
  console.log("employeeData", employeeData);
  if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
    res.status(400).send({ success: false, message: "please fill all feild " });
  } else {
    Employee_Data.createEmployee(employeeData, (err, employees) => {
      if (err) res.send(err);
      res.json({
        status: true,
        message: "Employee Created Successfully",
        employees,
      });
    });
  }
};

// update employee
exports.updateEmployee = (req, res) => {
  const employeeData = new Employee_Data(req.body);
  console.log("employeeData", employeeData);
  if (req.body.constructor === Object && Object.keys(req.body).length === 0) {
    res
      .status(400)
      .send({ success: false, message: "please fill all fields " });
  } else {
    Employee_Data.updateEmployee(
      req.params.id,
      employeeData,
      (err, employees) => {
        if (err) res.send(err);
        res.json({
          status: true,
          message: "Employee Updated Successfully",
          employees,
        });
      }
    );
  }
};

// delete employee
exports.deleteEmployee = (req, res) => {
  Employee_Data.deletEmployeeData(req.params.id, (err, employees) => {
    if (err) res.send(err);
    res.json({
      status: true,
      message: "Employee Deleted Successfully",
      employees,
    });
  });
};
