// creating table column here using constructor function 

const Employee_Data = function (employee) {
    this.first_name = employee.first_name;
    this.lasrt_name = employee.lasrt_name;
    this.email = employee.email;
    this.phone = employee.phone;
    this.organization = employee.organization;
    this.designation = employee.designation;
    this.salary = employee.salary;
    this.status = employee.status;
    this.created_at = employee.created_at;
    this.updated_at = employee.updated_at;
};

module.exports = Employee_Data;

// step 2 creating table column



