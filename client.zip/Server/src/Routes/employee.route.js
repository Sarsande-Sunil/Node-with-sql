const express = require("express");

const router = express.Router();

const employeeController = require("../Controllers/employee.controller");

// get all epmloyee
router.get("/all", employeeController.getAllEmployeeList);

// get employee by id

router.get("/:id", employeeController.getEmployeeByid);

// create new employee 
router.post("/new", employeeController.createNewEmployee);

// update employee

router.put("/update/:id", employeeController.updateEmployee);

// delete employee

router.delete("/delete/:id", employeeController.deleteEmployee);

module.exports = router;